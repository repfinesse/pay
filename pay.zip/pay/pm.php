<?php
session_start();
require_once "class.php";
if ( empty( $_GET[ 'action' ] ) )
    $_GET[ 'action' ] = 'process';
switch ( $_GET[ 'action' ] ) {
    case 'process':
        $s = $_POST[ "id" ] . "_" . $_POST[ "q" ];
        $a = getPrice($_POST["q"]);
        $a      = $a["total"];
        $url    = 'https://perfectmoney.is/api/step1.asp';
        $myvars = array(
             "PAYEE_ACCOUNT" => "U19913012",
            "PAYEE_NAME" => "Repfinesse",
            "PAYMENT_AMOUNT" => $a,
            "PAYMENT_UNITS" => "USD",
            "PAYMENT_ID" => "testing",
            "STATUS_URL" => "https://www.repfinesse.com/perfectmoney/ipn",
            "PAYMENT_URL" => "https://www.repfinesse.com/receipts",
            "PAYMENT_URL_METHOD" => "POST",
            "NOPAYMENT_URL" => "https://www.repfinesse.com/receipts",
            "NOPAYMENT_URL_METHOD" => "POST",
            "BAGGAGE_FIELDS" => $s,
            "INTERFACE_LANGUAGE" => "en_US" 
        );
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Processing Payment...</title>
    <style>
        html {
  box-sizing: border-box;
}
*, *:before, *:after {
  box-sizing: inherit;
}

.spinner {
    height: 100%;
    width: 100%;
    position: fixed;
    z-index: 10
}

.spinner .spinWrap {
    width: 200px;
    height: 100px;
    position: fixed;
    top: 42%;
    left: 50%;
    margin-left: -98px;
    margin-top: -50px
}

.spinner .spinnerImage {
    margin: 24px 0 0 -30px;
    background: url(https://www.paypalobjects.com/images/checkout/hermes/icon_ot_spin_lock_skinny.png) no-repeat
}

.spinner .loader,.spinner .spinnerImage {
    height: 100px;
    width: 100px;
    position: absolute;
    top: 0;
    left: 50%;
    opacity: 1;
    filter: alpha(opacity=100)
}

.spinner .loader {
    margin: 0 0 0 -55px;
    background-color: transparent;
    -webkit-animation: g .7s infinite linear;
    animation: g .7s infinite linear;
    border-left: 5px solid #cbcbca;
    border-right: 5px solid #cbcbca;
    border-bottom: 5px solid #cbcbca;
    border-top: 5px solid #2380be;
    border-radius: 100%
}

.spinner .bmlLoadingMessage,.spinner .genericLoadingMessage,.spinner .loginLoadingMessage {
    -ms-box-sizing: border-box;
    box-sizing: border-box;
    width: 100%;
    margin-top: 125px;
    text-align: center;
    z-index: 100
}

.spinner.preloader {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    background-color: #fff
}

@-webkit-keyframes g {
    0% {
        -webkit-transform: rotate(0deg)
    }

    to {
        -webkit-transform: rotate(359deg)
    }
}

@keyframes g {
    0% {
        transform: rotate(0deg)
    }

    to {
        transform: rotate(359deg)
    }
}

@media only screen and (max-width: 768px) {
    .spinner .spinWrap {
        width:200px;
        height: 100px;
        position: fixed;
        top: 40%;
        left: 50%;
        margin-left: -93px;
        margin-top: -50px
    }
}

    </style>
</head>

<body onLoad="document.forms['perfectmoney'].submit();">

<form action="<?php
        echo $url;
?>" method="POST" name="perfectmoney">
    <?php
        foreach ( $myvars as $k => $v ) {
            echo '<input type="hidden" name="' . $k . '" value="' . $v . '">';
        }
?>
</form>
<div class="preloader spinner" id="preloaderSpinner">
        <div class="spinWrap">
            <span class="spinnerImage"></span> <span class="loader"></span>
        </div>
    </div>
</body>
</html>

<?php
        break;
    case 'ipn':
        define( "PASSWORD_ACCOUNT", "Panther12" );
        if ( !isset( $_POST[ 'PAYMENT_ID' ] ) || !isset( $_POST[ 'PAYEE_ACCOUNT' ] ) || !isset( $_POST[ 'PAYMENT_AMOUNT' ] ) || !isset( $_POST[ 'PAYMENT_UNITS' ] ) || !isset( $_POST[ 'PAYMENT_BATCH_NUM' ] ) || !isset( $_POST[ 'PAYER_ACCOUNT' ] ) || !isset( $_POST[ 'TIMESTAMPGMT' ] ) ) {
            header( "Location: cancel.php" );
            exit( );
        }
        $paymentID           = $_POST[ 'PAYMENT_ID' ];
        $payeeAccount        = $_POST[ 'PAYEE_ACCOUNT' ];
        $paymentAccount      = $_POST[ 'PAYMENT_AMOUNT' ];
        $paymentUnits        = $_POST[ 'PAYMENT_UNITS' ];
        $paymentBatchNum     = $_POST[ 'PAYMENT_BATCH_NUM' ];
        $payerAccount        = $_POST[ 'PAYER_ACCOUNT' ];
        $timestampPGMT       = $_POST[ 'TIMESTAMPGMT' ];
        $v2Hash              = $_POST[ 'V2_HASH' ];
        $baggageFields       = $_POST[ 'BAGGAGE_FIELDS' ];
        $alternatePhraseHash = strtoupper( md5( PASSWORD_ACCOUNT ) );
        $hash                = $paymentID . ':' . $payeeAccount . ':' . $paymentAccount . ':' . $paymentUnits . ':' . $paymentBatchNum . ':' . $payerAccount . ':' . $alternatePhraseHash . ':' . $timestampPGMT;
        $hash2               = strtoupper( md5( $hash ) );
        if ( $hash2 != $v2Hash ) {
            exit;
        }
        $method    = "Uploaded funds";
        $completed = "Completed";
        $today     = date( 'Y-m-d' );
        $type      = "Perfect Money";
        $uses      = $p->ipn_data[ 'quantity' ];
        $id        = $p->ipn_data[ 'custom' ];
        $email     = $p->ipn_data[ 'payer_email' ];
        $admin     = new Admin;
        $username  = $admin->getUsername( $id );
        $admin->topup( $uses, $id );
        break;
}
?>