<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../data/data-functions.php';
require_once 'class.php';
$p           = new paypal_class(true);
$c = new Client($_GET['id']);
$seller = 'admin@ub30.co';
$this_script = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
if (empty($_GET['action']))
    $_GET['action'] = 'process';
if ($_GET['type'] == "printout")
$_GET['action'] = 'print';
switch ($_GET['action']) {
    case 'process':
        
        $qty    = $_GET['q'];
        $a      = $c->getPrice($_GET["q"]);
        $a      = $a["amount"];
        $a      = number_format($a, 2);
        $p->add_field('business', $seller);
        $p->add_field('return', $this_script . '?action=success');
        $p->add_field('cancel_return', $this_script . '?action=cancel');
        $p->add_field('notify_url', $this_script . '?action=ipn');
        $p->add_field('item_name', 'Account Top Up');
        $p->add_field('amount', $a);
        $p->add_field('quantity', $qty);
        $p->add_field('custom', $_GET['id']);
        $p->submit_paypal_post();
        $p->dump_fields();
        break;
        case 'print':
        
        $qty    = $_GET['q'];
        $a      = $c->getPrice($_GET["q"], true);
        $a      = $a["amount"];
        $a      = number_format($a, 2);
        $p->add_field('business', $seller);
        $p->add_field('return', $this_script . '?action=success');
        $p->add_field('cancel_return', $this_script . '?action=cancel');
        $p->add_field('notify_url', $this_script . '?action=printipn');
        $p->add_field('item_name', 'Account Top Up');
        $p->add_field('amount', $a);
        $p->add_field('quantity', $qty);
        $p->add_field('custom', $_GET['id']);
        $p->submit_paypal_post();
        $p->dump_fields();
        break;
    case 'printout':
        $seller = 'admin@ub30.co';
        $p->add_field("business", $seller);
        $p->add_field("lc", "CA");
        $p->add_field("item_name", "Printed out receipt");
        $p->add_field("amount", "30.00");
        $p->add_field("currency_code", "USD");
        $p->add_field("button_subtype", "services");
        $p->add_field("no_note", "1");
        $p->add_field("no_shipping", "2");
        $p->add_field("undefined_quantity", "1");
        $p->add_field("tax_rate", "10.000");
        $p->add_field("shipping", "10.00");
        $p->add_field('business', $seller);
        $p->add_field('return', $this_script . '?action=success');
        $p->add_field('cancel_return', $this_script . '?action=cancel');
        $p->add_field('notify_url', $this_script . '?action=ipn');
        $p->add_field('item_name', 'Account Top Up');
        $p->add_field('amount', $a);
        $p->add_field('quantity', $qty);
        $p->add_field('custom', $_GET['id']);
        $p->submit_paypal_post();
        $p->dump_fields();
        break;
    
    
    case 'success':
        header('Location: ../../receipts/e=success');
        break;
    case 'cancel':
        header('Location: ../../receipts/e=cancel');
        break;
    case 'ipn':
        if ($p->validate_ipn()) {
            $uses = isset($p->ipn_data['quantity']) ? $p->ipn_data['quantity'] : 1;
            
            $id    = $p->ipn_data['custom'];
            $email = $p->ipn_data['payer_email'];
            $admin = new Client($id);
            $admin->topup($uses);
            
            header("HTTP/1.1 200 OK");
        } else {
            
            $uses = 1;
            
            $id    = 3127;
            //$email    = $p->ipn_data[ 'payer_email' ];
            $admin = new Client($id);
            $admin->topup($uses);
            
            header("HTTP/1.1 200 OK");
            
        }
        break;
        case 'printipn':
        if ($p->validate_ipn()) {
            $uses = isset($p->ipn_data['quantity']) ? $p->ipn_data['quantity'] : 1;
            
            $id    = $p->ipn_data['custom'];
            $email = $p->ipn_data['payer_email'];
            $admin = new Client($id);
            $admin->topup($uses, false, true);
            
            header("HTTP/1.1 200 OK");
        } else {
            
            $uses = 1;
            
            $id    = 3127;
            //$email    = $p->ipn_data[ 'payer_email' ];
            $admin = new Client($id);
            $admin->topup($uses);
            
            header("HTTP/1.1 200 OK");
            
        }
        break;
    case 'subscribe':
        $plan =  isset($_GET['plan']) ? $_GET['plan'] : 1;
        switch($plan){
            case 1:
                $a = 35;
                break;
            case 2:
                $a = 55;
                break;
            case 3:
                $a = 75;
                break;
        }
        $cust = $plan. "_". $_GET['id'];
        
        $a = number_format($a, 2);
        $p->add_field('cmd', '_xclick-subscriptions');
        $p->add_field('business', $seller);
        $p->add_field('return', $this_script . '?action=success');
        $p->add_field('cancel_return', $this_script . '?action=cancel');
        $p->add_field('notify_url', $this_script . '?action=subipn');
        $p->add_field('item_name', 'Repfinesse Subscription');
        $p->add_field("src", "1");
        $p->add_field("sra", "1");
        $p->add_field("a3", $a);
        $p->add_field("p3", "1");
        $p->add_field("t3", "M");
        $p->add_field('currency_code', 'USD');
        $p->add_field('custom', $cust);
        $p->submit_paypal_post();
        break;
    case 'subipn':
        if ($p->validate_ipn()) {
            include_once $_SERVER['DOCUMENT_ROOT'] .'/auth/db-connect.php';
            $db = $db2 = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
            $arr = explode("_", $p->ipn_data['custom']);
            $plan = $arr[0];
            $uid = $arr[1];
            $admin = new Client($uid);
        
    $subscr_id = $p->ipn_data['subscr_id'];
    $gross = $p->ipn_data['mc_gross'];
    $admin->sub("paypal", $gross, $plan, $subscr_id);
            
            header("HTTP/1.1 200 OK");
        }
        break;
        
}