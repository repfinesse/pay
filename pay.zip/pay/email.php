<?php
$e_body = "
<!DOCTYPE html>
<html>
<body>
	<table class='entire-page' style='background: #C7C7C7;width: 100%;padding: 20px 0;font-family: 'Lucida Grande', 'Lucida Sans Unicode', Verdana, sans-serif;line-height: 1.5;'>
		<tr>
			<td style='font-size: 13px;color: #878787;'>
				<table class='email-body' style='max-width: 600px;min-width: 320px;margin: 0 auto;background: white;border-collapse: collapse;img { max-width: 100%;'>
					<tr>
						<td class='email-header' style='font-size: 13px;color: #878787;background: #00C967;padding: 30px;'>
							<a href='https://repfinesse.com' style='color: #2F82DE;font-weight: bold;text-decoration: none;'><img alt='Order Success' src='https://www.repfinesse.com/images/logo_allblack.png' width='100'></a>
						</td>
					</tr>
					<tr>
						<td class='news-section' style='font-size: 13px;color: #878787;padding: 20px 30px;'>
							<h1 style='color: black;font-size: 25px;'>Thank you for your order!</h1>
							<p style='font-size: 13px;color: #878787;'>Your repfinesse account @{$username} has been successfully topped up with {$uses} {$r} and you can use it <a href='https://www.repfinesse.com/receipts' style='color: #2F82DE;font-weight: bold;text-decoration: none;'>here</a>.</p>
						
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
";

$e_alt = "
https://repfinesse.com

 
** THANK YOU FOR YOUR ORDER
------------------------------------------------------------

Your repfinesse account({$username})has been successfully topped up with {$uses} receipt(s) and you can use it here (https://www.repfiensse.com/receipts/receipts) . 
";
?>