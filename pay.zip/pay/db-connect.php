<?php 
include_once('config.inc.php'); 
require_once('MysqliDb.php');
$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE); 
$prefix = 'lp_'; 


$db = new Mysqlidb ('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
