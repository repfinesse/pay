<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
function getPrice( $q )
{
    if ( $q >= 5 ) {
        $a = 10;
    } else {
        $a = 13;
    }
    $t = number_format( $a * $q, 2 );
    $b = array(
         "amount" => number_format( $a, 2 ),
        "amountRaw" => $a,
        "quantity" => $q,
        "total" => $t 
    );
    return $b;
}
class Client
{
    private $username;
    private $email;
    private $id;
    private $uses;
    private $used;
    
    
    public function __construct( $id )
    {
        require_once $_SERVER['DOCUMENT_ROOT'] .'/auth/db-connect.php'; $db = new Mysqlidb( 'localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes' );
        $db->where( "id", $id );
        $results = $db->getOne( "singleuse" );
        $db->disconnect();
        $this->username = $results[ 'username' ];
        $this->email    = $results[ 'email' ];
        $this->id       = $results[ 'id' ];
        $this->uses     = $results[ 'uses' ];
        $this->used     = $results[ 'used' ];
    }
    function checkCode( )
    {
        if ( $this->uses <= $this->used ) {
            return false;
        } else {
            return true;
        }
    }
    function getUses( )
    {   $uses = array();
        $uses['uses'] = $this->uses;
        $uses['used'] = $this->used;
        $uses['left'] = $this->uses - $this->used;
        return $uses;
    }
    function addUse( $json )
    {
        include_once $_SERVER['DOCUMENT_ROOT'] .'/auth/db-connect.php';
        $db = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
        $newUses = $this->used + 1;
        $sql2    = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
        $sql2->where( "username", $this->username );
        $data = array(
             "used" => $newUses 
        );
        $sql2->update( "singleuse", $data );
        $sql2->disconnect();
        $sql3 = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
        $data = array(
             "user_id" => $this->id,
            "message" => $json 
        );
        $sql3->insert( "receipts", $data );
        $sql3->disconnect();
        $this->used = $newUses;
    }
    function topup( $uses )
    {
        include_once $_SERVER['DOCUMENT_ROOT'] .'/auth/db-connect.php'; $db = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
        $user            = array( );
        $user[ 'added' ] = $uses;
        $user[ 'type' ]  = "topup";
        $adduses         = $this->uses + $uses;
        $data            = array(
             "uses" => $adduses 
        );
        $sql2            = new Mysqlidb('localhost', 'repftfef_codes', 'alwknAFlwknd3ialko', 'repftfef_codes');
        $sql2->where( "id", $this->id );
        if ( $sql2->update( "singleuse", $data ) ) {
            $x = $this->sendEmail( $user );
            return $x;
        }
    }
    function sendEmail( array $vars )
    {
        require $_SERVER['DOCUMENT_ROOT'] .'/includes/PHPMailer/Exception.php';
        require $_SERVER['DOCUMENT_ROOT'] .'/includes/PHPMailer/PHPMailer.php';
        require $_SERVER['DOCUMENT_ROOT'] .'/includes/PHPMailer/SMTP.php';
        $user     = $vars;
        $to       = $this->email;
        $uses     = $user[ 'added' ];
        $r        = $uses == 1 ? "use" : "uses";
        $username = $fullname = $this->username;
        $title   = "Thank you for your order!";
        $subject = "Your repfinesse account top-up was successful";
        $content = "<p style='font-size: 13px;color: #878787;'>Your repfinesse account @{$username} has been successfully topped up with {$uses} {$r} and you can use it <a href='https://www.repfinesse.com/receipts' style='color: #2F82DE;font-weight: bold;text-decoration: none;'>here</a>.</p>";
        $e_head = <<<WWW
    <center>
<table class='entire-page' style='background: #C7C7C7;width: 100%;padding: 20px 0;font-family: 'Lucida Grande', 'Lucida Sans Unicode', Verdana, sans-serif;line-height: 1.5;'>
        <tr>
            <td style='font-size: 13px;color: #878787;'>
                <table class='email-body' style='max-width: 600px;min-width: 320px;margin: 0 auto;background: white;border-collapse: collapse;img { max-width: 100%;'>
                    <tr>
                        <td class='email-header' style='font-size: 13px;color: #878787;background: #00C967;padding: 30px;'>
                            <a href='https://repfinesse.com' style='color: #2F82DE;font-weight: bold;text-decoration: none;'><img alt='Order Success' src='https://www.repfinesse.com/images/logo_allblack.png' width='100'></a>
                        </td>
                    </tr>
                    <tr>
                        <td class='news-section' style='font-size: 13px;color: #878787;padding: 20px 30px;'>
                        <h1>{$title}</h1>
                            <p><strong>Hello {$fullname}, </strong></p>
                        <p>&nbsp;</p>    
WWW;
     $e_foot = <<<WWW
        
                        <p>&nbsp;</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</center>
WWW;
        $e_body = $e_head . $content . $e_foot;
        $mail   = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug  = 0;
        $mail->Host       = 'repfinesse.com';
        $mail->Port       = 465;
        $mail->SMTPSecure = 'ssl';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'noreply@repfinesse.com';
        $mail->Password   = '^p&CGtZlod[a';
        $mail->From       = "noreply@repfinesse.com";
        $mail->FromName   = "RepFinesse";
        $mail->addAddress( $to, $username );
        $mail->addReplyTo( "admin@repfinesse.com", "Reply" );
        $mail->addBCC( "repfinesse@gmail.com" );
        $mail->isHTML( true );
        $mail->Subject = $subject;
        $mail->Body    = $e_body;
        if ( $mail->send() ) {
            return "Mail aint send for some reason";
        } else {
            return true;
        }
        ;
    }
}