<?php
error_reporting( E_ALL );
ini_set( 'display_errors', 1 );
if(isset($_GET['action']) && $_GET['action'] == "subscribe"){
    $newSub  = true;
}
$config = require_once('stripe/webhook_config.php');
require_once('stripe/webhookclass.php');
require_once($config['stripe_path']);
require_once "../data/data-functions.php";
$event_array = require_once('stripe/eventarray.php');

if($config['log_type'] === 1){
    $config['db'] = new PDO("mysql:host={$config['db_host']};dbname={$config['db_name']}", $config['db_user'], $config['db_pass']);
}

\Stripe\Stripe::setApiKey($config['api_key']);
if($newSub){
    $cli = new Client($_GET['id']);
    $email = $cli->email();
    
    switch($_GET['plan']){
            case 1:
                $a = 3500;
                $r = 15;
                break;
            case 2:
                $a = 5500;
                $r = 30;
                break;
            case 3:
                $a = 7500;
                $r = 1;
                break;
        }
 
$session = \Stripe\Checkout\Session::create([
  'payment_method_types' => ['card'],
  'subscription_data' => [
    'items' => [[
      'plan' => $config['plans'][$_GET['plan']],
    ]],],
  'success_url' => 'https://repfinesse.com/receipts?e=success',
  'cancel_url' => 'https://repfinesse.com/receipts?e=cancel',
  'client_reference_id' => $_GET['plan']."_".$_GET['id']
]);
}else{
    $c = new Client($_GET['id']);
$arr = $_GET['type'] == "printout" ? $c->getPrice($_GET["q"], true) : $c->getPrice($_GET["q"]);
    $a =  $arr['amountRaw'] * 100 ;
    $q = $arr['quantity'];
    $name  = $_GET['type'] == "printout" ? "Repfinesse Printout Topup": 'Repfinesse Account Top-Up';
    $session = \Stripe\Checkout\Session::create([
  'payment_method_types' => ['card'],
  'line_items' => [[
    'name' => $name,
    //'description' => 'Comfortable cotton t-shirt',
    //'images' => ['https://example.com/t-shirt.png'],
    'amount' => $a,
    'currency' => 'usd',
    'quantity' => $q,
  ]],
  'success_url' => 'https://repfinesse.com/receipts?e=success',
  'cancel_url' => 'https://repfinesse.com/receipts?e=cancel',
  'client_reference_id' => $_GET['id']
]);
    
}

$sesh = json_decode( $session );  


?>

<!DOCTYPE html>
<html>
<head>
    <script src="https://js.stripe.com/v3/"></script>
	<title>Processing Payment...</title>
	<style>
		html {
  box-sizing: border-box;
}
*, *:before, *:after {
  box-sizing: inherit;
}

.spinner {
    height: 100%;
    width: 100%;
    position: fixed;
    z-index: 10
}

.spinner .spinWrap {
    width: 200px;
    height: 100px;
    position: fixed;
    top: 42%;
    left: 50%;
    margin-left: -98px;
    margin-top: -50px
}

.spinner .spinnerImage {
    margin: 24px 0 0 -30px;
    background: url(https://www.paypalobjects.com/images/checkout/hermes/icon_ot_spin_lock_skinny.png) no-repeat
}

.spinner .loader,.spinner .spinnerImage {
    height: 100px;
    width: 100px;
    position: absolute;
    top: 0;
    left: 50%;
    opacity: 1;
    filter: alpha(opacity=100)
}

.spinner .loader {
    margin: 0 0 0 -55px;
    background-color: transparent;
    -webkit-animation: g .7s infinite linear;
    animation: g .7s infinite linear;
    border-left: 5px solid #cbcbca;
    border-right: 5px solid #cbcbca;
    border-bottom: 5px solid #cbcbca;
    border-top: 5px solid #2380be;
    border-radius: 100%
}

.spinner .bmlLoadingMessage,.spinner .genericLoadingMessage,.spinner .loginLoadingMessage {
    -ms-box-sizing: border-box;
    box-sizing: border-box;
    width: 100%;
    margin-top: 125px;
    text-align: center;
    z-index: 100
}

.spinner.preloader {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    background-color: #fff
}

@-webkit-keyframes g {
    0% {
        -webkit-transform: rotate(0deg)
    }

    to {
        -webkit-transform: rotate(359deg)
    }
}

@keyframes g {
    0% {
        transform: rotate(0deg)
    }

    to {
        transform: rotate(359deg)
    }
}

@media only screen and (max-width: 768px) {
    .spinner .spinWrap {
        width:200px;
        height: 100px;
        position: fixed;
        top: 40%;
        left: 50%;
        margin-left: -93px;
        margin-top: -50px
    }
}

	</style>
</head>
<body  >
	<div class="p reloader spinner" id="preloaderS pinner">
		<div class="s pinWrap">
			<span class="spin nerImage"></span> <span class="loa der"></span>
		</div>
	</div>
	<script>
	var pk = "<?php echo $config['pk']; ?>"
  var stripe = Stripe(pk);
  window.addEventListener('load', function () {
    // When the customer clicks on the button, redirect
    // them to Checkout.
    stripe.redirectToCheckout({
        
      sessionId: "<?php echo $session['id'];?>"
    })
    .then(function (result) {
      if (result.error) {
        // If `redirectToCheckout` fails due to a browser or network
        // error, display the localized error message to your customer.
        var displayError = document.getElementById('error-message');
        displayError.textContent = result.error.message;
      }
    });
  });
</script>
</body>

</html>




